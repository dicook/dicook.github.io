Taming-of-Chance
================

A collaboration of 585 students creating a gripping story.
